/*
    options.js - Archive Page Extension Options Logic
    Handles all scripting for options.html
    © 2026 John Navas, All Rights Reserved
*/

const MAP = {
    cb: [
        { k: 'cbButtonNew', i: 'cbButtonNew' },
        { k: 'cbPageNew', i: 'cbPageNew' },
        { k: 'cbArchiveNew', i: 'cbArchiveNew' },
        { k: 'cbSearchNew', i: 'cbSearchNew' }
    ],
    rd: [{ k: 'archiveTld', n: 'archiveTld' }, { k: 'toolbarAction', n: 'toolbarAction' }],
    tab: { 'tabAdj': 'adjacent', 'tabEnd': 'end', 'tabAct': 'active' }
};

async function restoreOptions() {
    // FIXED: Default initialization for first run
    const items = await chrome.storage.sync.get({
        tabCtl: 'adjacent',
        cbButtonNew: true,
        cbPageNew: true,
        cbArchiveNew: true,
        cbSearchNew: true,
        archiveTld: "today",
        toolbarAction: "menu"
    });

    const isAndroid = /\bAndroid\b/i.test(navigator.userAgent);
    if (isAndroid) {
        ['sectionToolbarAction', 'sectionOpenIn', 'sectionActivate'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.disabled = true;
        });
    }

    // Restore checkboxes
    MAP.cb.forEach(c => {
        const el = document.getElementById(c.i);
        if (el) el.checked = items[c.k];
    });

    // Restore radio buttons
    MAP.rd.forEach(r => {
        const el = document.querySelector(`input[name="${r.n}"][value="${items[r.k]}"]`);
        if (el) el.checked = true;
    });

    // Restore Open In radios
    const tabId = Object.keys(MAP.tab).find(key => MAP.tab[key] === items.tabCtl);
    if (tabId) document.getElementById(tabId).checked = true;
}

async function saveOptions() {
    const settings = {};
    MAP.cb.forEach(c => { settings[c.k] = document.getElementById(c.i).checked; });
    MAP.rd.forEach(r => { settings[r.k] = document.querySelector(`input[name="${r.n}"]:checked`).value; });
    settings.tabCtl = MAP.tab[document.querySelector('input[name="tabCtl"]:checked').id];

    await chrome.storage.sync.set(settings);
    const status = document.getElementById('status');
    status.textContent = 'Saved';
    setTimeout(() => { status.textContent = ''; }, 750);
}

document.addEventListener('DOMContentLoaded', async () => {
    await restoreOptions();

    document.querySelectorAll('input').forEach(input => {
        input.addEventListener('change', saveOptions);
    });

    document.getElementById('bReview').addEventListener('click', () => window.open('https://chromewebstore.google.com/detail/archive-page/gcaimhkfmliahedmeklebabdgagipbia/reviews', '_blank'));
    document.getElementById('bIssue').addEventListener('click', () => window.open('https://github.com/JNavas2/Archive-Page/issues', '_blank'));
    document.getElementById('bSuggest').addEventListener('click', () => window.open('https://github.com/JNavas2/Archive-Page/discussions', '_blank'));

    document.getElementById('bClose').addEventListener('click', () => {
        chrome.tabs.getCurrent(tab => {
            if (tab) chrome.tabs.remove(tab.id);
            else window.close();
        });
    });

    document.getElementById('bRemove').addEventListener('click', () => chrome.management.uninstallSelf({ showConfirmDialog: true }));
    document.getElementById('bHelp').addEventListener('click', () => window.open('https://github.com/JNavas2/Archive-Page', '_blank'));
});